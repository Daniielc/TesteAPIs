#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include "lista.h"

void menu();

void menu()
{
	setlocale(LC_ALL, "");
	FILA *f1 = (FILA *)malloc(sizeof(FILA));
	iniFila(f1);

	int opc, valor;
	for (;;)
	{
		printf("\n==========MENU=========="
			   "\n1 - Inserir na fila "
			   "\n2 - Remover da fila"
			   "\n3 - Imprimir a fila"
			   "\nDigite uma opcao: ");
		scanf("%i", &opc);

		if (opc < 1 || opc > 3)
		{
			printf("\nFim do programa\n");
			break;
		}
		switch (opc)
		{
		case 1:
			printf("\n#-Inserido-#");
			printf("\nDigite uma valor para inserir na fila: ");
			scanf("%i", &valor);
			enfileira(valor, f1);
			break;

		case 2:
			printf("\n#-Removido-#");
			printf("\nValor removido da fila - resultado: %d\n", removFila(f1));
			break;

		case 3:
			if (f1 == NULL)
			{
				printf("\n#-Impressao-#");
				printf("Erro ao alocar. \n");
				exit(-1);
			}
			else
			{
				imprime(f1);
			}
			break;
		}
	}
}

void iniFila(FILA *f)
{
	f->ini = NULL;
	f->fim = NULL;
}

void enfileira(int dado, FILA *f)
{
	NO *ptr = (NO *)malloc(sizeof(NO));
	if (ptr == NULL)
	{
		printf("Erro ao alocar.\n");
		return;
	}
	else
	{
		ptr->dado = dado;
		ptr->prox = NULL;
		if (f->ini == NULL)
		{
			f->ini = ptr;
		}
		else
		{
			f->fim->prox = ptr;
		}
		f->fim = ptr;
		return;
	}
}

int removFila(FILA *f)
{
	NO *ptr = f->ini;
	int dado;
	if (ptr != NULL)
	{
		f->ini = ptr->prox;
		ptr->prox = NULL;
		dado = ptr->dado;
		free(ptr);
		if (f->ini == NULL)
		{
			f->fim = NULL;
		}
		return dado;
	}
	else
	{
		printf("Fila vazia. \n");
		return -1;
	}
}

void imprime(FILA *f)
{
	NO *ptr = f->ini;
	int i = 1;
	if (ptr != NULL)
	{
		while (ptr != NULL)
		{
			printf("%d : Valor: %d\n", i, ptr->dado);
			ptr = ptr->prox;
			i++;
		}
	}
	else
	{
		printf("Fila vazia.\n");
		return;
	}
}
