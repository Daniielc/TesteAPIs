#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

typedef struct NO{
	int dado;
	struct NO *prox;
}NO;

typedef struct FILA{
	NO *ini;
	NO *fim;
}FILA;

void menu();
void iniFila(FILA *f);
void enfileira(int dado, FILA *f);
int removFila(FILA *f);
void imprime(FILA *f);

