#include <stdio.h>
#include <stdlib.h>
#include "pilha.h"

	PILHA pilha_Operandos;
	PILHA pilha_Operadores;
	ITEM item;

int main(void) {
	char exp[10] = "(3-5)+7";

	printf("Inicio");


	cria(&pilha_Operandos);
	cria(&pilha_Operadores);

	item.value_char = '#';
	push(item, &pilha_Operadores);

	for(int i=0; i<7; i++){
		char value = exp[i];
		item.value_char = value;

		if(value == 43 || value == 45 || value == 42 || value == 47 || value == 40 || value == 41){
			if(value == 40){
				// Se encontrar (, empilhar
				push(item, &pilha_Operadores);
			} else {
				// Conferir precedencia
				//if(compararPrecedencia(value, &pilha_Operadores)==1){
					//empilhar
				//}//
				// nao empilhar

			}
		} else {
			printf("\nOperando: %c", value);
			push(item, &pilha_Operandos);
		}
	}

	return EXIT_SUCCESS;
}

int compararPrecedencia(double value, PILHA *pilha){

	printf("\nvalue: %d\n", value);

	ITEM itemNoTopo;
	itemNoTopo.value_char = '#';

	look(pilha, &itemNoTopo);


	int prec1, prec2;


	// tambem nao funciona...
	if(value == 42 || value == 47){;
		prec1 = 3;
	} else if (value==43 || value==45){
		prec1 = 2;
	} else if (value==40){
		prec1 = 1;
	} else {
		prec1 = 0;
	}

	printf("prec1 = %i", prec1);

	return 0;
}
