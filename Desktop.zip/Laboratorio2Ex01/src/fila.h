#if !defined(FILA_H)
#define FILA_H

typedef struct CELULA_TAG *PONT;

typedef struct {
	char value_char;
} ITEM;

typedef struct CELULA_TAG {
	ITEM item;
	PONT prox;
} CELULA;

typedef struct {
	PONT inicio, final;
} FILA;

void cria(FILA*);
int vazia(FILA);
int enfileira(ITEM, FILA*);
int desenfileira(FILA*, ITEM*);

#endif
