/*
 ============================================================================
 Name        : main.c
 Author      : Victor Barcellos
 Version     :
 Copyright   : Your copyright notice
 Description : Lab 02 ex 01
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include "fila.h"

int main(void) {
	FILA fila;
	ITEM item;
	char elem;

	int opcao = 0;

	printf("\n==== MENU ====");
	printf("\n0 - Criar fila vazia");
	printf("\n1 - Inserir elemento");
	printf("\n2 - Remover elemento");
	fflush(stdin);
	scanf("%d", &opcao);

	switch (opcao) {
		case 0:
			cria(&fila);
			break;
		case 1:
			printf("Digite um elemento: ");
			fflush(stdin);
			scanf("%c", &elem);
			item.value_char = elem;

			enfileira(item, &fila);
			break;
		case 2:
			desenfileira(&fila, &item);
			break;
		default:
			break;
	}

	system("pause");
	return 0;
}
