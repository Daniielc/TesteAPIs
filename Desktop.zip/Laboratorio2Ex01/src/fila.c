#include <stdio.h>
#include <stdlib.h>
#include "fila.h"

void cria(FILA *fila) {
	fila->final = (PONT)malloc(sizeof(CELULA));
	fila->inicio = fila->final;
	fila->final->prox = NULL;
}

int vazia(FILA fila) {
	return (fila.inicio == fila.final);
}

int enfileira(ITEM novo_Item, FILA *fila) {
	fila->final->prox = (PONT)malloc(sizeof(CELULA));
	fila->final = fila->final->prox;
	fila->final->item = novo_Item;
	fila->final->prox = NULL;
	return 0;
}

int desenfileira(FILA *fila, ITEM *item) {
	PONT q;

	if (vazia(*fila))
		return -1;

	q = fila->inicio;
	fila->inicio = fila->inicio->prox;
	*item = fila->inicio->item;

	free(q);
	return 0;
}


