/*
 ============================================================================
 Name        : main.c
 Author      : Victor Barcellos
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include "pilha.h"


/*
	TABELA ASCII
		40 = (
		41 = )
		42 = *
		43 = +
		45 = -
		47 = /
		67 = #
*/

	PILHA pilha_Operandos;
	PILHA pilha_Operadores;
	ITEM item;

int main(void) {
	char exp[10] = "(3-5)+7";

	printf("Inicio");
//	PILHA pilha_Operandos;
//	PILHA pilha_Operadores;
//	ITEM item;

	// Cria as pilhas
	cria(&pilha_Operandos);
	cria(&pilha_Operadores);

	// FDE
	item.value_char = '#';
	push(item, &pilha_Operadores);

	// Imprime os valores de cada char na tabela ASC
	//	for(int i=0; i<7; i++){
	//		printf("\n%d", exp[i]);
	//	}

	// Imprime cada um dos chars da exp
	//	for(int i=0; i<7; i++){
	//		printf("\n%c", exp[i]);
	//	}

	for(int i=0; i<7; i++){
		char value = exp[i];
		item.value_char = value;


//		printf("\nValue c: %c", value); // valor
//		printf("\nValue d: %d", value); // pos do valor na tabela asc


		if(value == 43 || value == 45 || value == 42 || value == 47 || value == 40 || value == 41){
			if(value == 40){
				// Se encontrar (, empilhar
				push(item, &pilha_Operadores);
			} else {
				// Conferir precedencia
				if(compararPrecedencia(value, &pilha_Operadores)==1){
					//empilhar
				}
				// n�o empilhar

			}
//			printf("\nOperador: %c", value);
//			push(item, &pilha_Operadores);
		} else {
			printf("\nOperando: %c", value);
			push(item, &pilha_Operandos);
		}
	}

//	int tamanhoPilhaOperandos = tamanho(pilha_Operandos);
//	int tamanhoPilhaOperadores = tamanho(pilha_Operadores);
//
//	printf("\n\nTamanho da pilha operandos: %i\n", tamanhoPilhaOperandos);
//	printf("Tamanho da pilha operadores: %i\n", tamanhoPilhaOperadores);
//
//	printf("\n== Pilha operandos ==\n");
//	printStack_Char(pilha_Operandos);
//	printf("\n== Pilha operadores ==\n");
//	printStack_Char(pilha_Operadores);

	return EXIT_SUCCESS;
}

int compararPrecedencia(double value, PILHA *pilha){
	// Comparar value com valor no topo da pilha
	// retorna 1 se value tiver precedencia maior
	// retorna 2 se elemento da pilha tiver precedencia maior

//	printf("\nPode empilhar method:");
	printf("\nvalue: %d\n", value);

	ITEM itemNoTopo;
	itemNoTopo.value_char = '#';

	look(pilha, &itemNoTopo);

//	printf("\nvalue no topo %d", itemNoTopo.value_char);

//	printf("\n%d vs %d", value, itemNoTopo.value_char); // Nao funciona misteriosamente

//	40 = (
//	41 = )
//	42 = *
//	43 = +
//	45 = -
//	47 = /
//	67 = #

	// */ > +- > ( > FDE
	// 42 e 47 > 43 e 45 > 40 > 67
	// precedencias: 3 > 2 > 1 > 0

	int prec1, prec2;

//	int novoValor = (int) value;
//	printf('int value %i', (int) value);

	// N�o funciona com value porque n�o � int, nao funciona com cast to int por ????
//	switch (novoValor) {
//		case 42:
//		case 47:
//			prec1 = 3;
//			break;
//		case 43:
//		case 45:
//			prec1 = 2;
//			break;
//		case 40:
//			prec1 = 1;
//			break;
//		default:
//			prec1 = 0;
//			break;
//	}


	// tambem nao funciona...
	if(value == 42 || value == 47){;
		prec1 = 3;
	} else if (value==43 || value==45){
		prec1 = 2;
	} else if (value==40){
		prec1 = 1;
	} else {
		prec1 = 0;
	}

	printf("prec1 = %i", prec1);

	return 0;
}
