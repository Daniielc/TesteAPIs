#include <stdio.h>
#include <stdlib.h>
#include "pilha.h"

// Cria pilha vazia
void cria(PILHA *pilha) {
	pilha->topo = (PONT)malloc(sizeof(CELULA));
	pilha->fundo = pilha->topo;
	pilha->topo->prox = NULL;
	pilha->tamanho = 0;
}

// Verifica se a pilha esta vazia
int vazia(PILHA pilha) {
	return (pilha.topo == pilha.fundo);
}

// Empilha
int push(ITEM novo_Item, PILHA *pilha) {
	PONT aux;

	aux = (PONT)malloc(sizeof(CELULA));
	pilha->topo->item = novo_Item;
	aux->prox = pilha->topo;
	pilha->topo = aux;
	pilha->tamanho++;
	return 0;
}

// Desempilha
int pop(PILHA *pilha, ITEM *item) {
	PONT q;

	if (vazia(*pilha))
		return -1;

	q = pilha->topo;
	pilha->topo = q->prox;
	*item = q->prox->item;

	free(q);
	pilha->tamanho--;
	return 0;
}

// Olha mas n�o desempilha (item do topo)
int look(PILHA *pilha, ITEM *item) {
	if (vazia(*pilha))
		return -1;

	*item = pilha->topo->prox->item;
	return 0;
}

// Tamanho da pilha
int tamanho(PILHA pilha) {
	return pilha.tamanho;
}

// Exibe todos elementos
void printStack_Char(PILHA pilha) {
	PONT aux;

	aux = pilha.topo->prox;
	while (aux != NULL)
	{
		printf("%c\n", aux->item.value_char);
		aux = aux->prox;
	}
}

// Exibe todos elementos
void printStack_Float(PILHA pilha) {
	PONT aux;

	aux = pilha.topo->prox;
	while (aux != NULL)
	{
		printf("%.2f\n", aux->item.value_float);
		aux = aux->prox;
	}
}
