#if !defined(PILHA_H)
#define PILHA_H

typedef struct CELULA_TAG *PONT;

typedef struct {
	char value_char;
	float value_float;
} ITEM;

typedef struct CELULA_TAG {
	ITEM item;
	PONT prox;
} CELULA;

typedef struct {
	PONT fundo, topo;
	int tamanho;
} PILHA;

void cria(PILHA*);
int vazia(PILHA);
int push(ITEM, PILHA*);
int pop(PILHA*, ITEM*);
int look(PILHA*, ITEM*);
void printStack_Char(PILHA);
void printStack_Float(PILHA);
int tamanho(PILHA);

#endif // !defined(PILHA_H)
